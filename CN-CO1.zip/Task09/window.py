"""Link utilisation of stop-and-wait and sliding-window protocols on different links."""
import math


def utilisation(frame_bits, rate_bps, distance_m, window, speed=2e8):
    tx = frame_bits / rate_bps                  # transmission time
    prop = distance_m / speed                   # propagation time
    # TODO 1 (completed): a = prop / tx ; U = W / (1 + 2a), capped at 1
    a = prop / tx
    u = min(1.0, window / (1 + 2 * a))
    return u, a


links = [("Campus LAN, 200 m, 1 Gbps", 1e9, 200),
         ("City fibre, 50 km, 1 Gbps", 1e9, 50_000),
         ("Satellite, 36,000 km, 10 Mbps", 10e6, 36_000_000)]
for name, rate, dist in links:
    u1, a = utilisation(12_000, rate, dist, 1)
    u7, _ = utilisation(12_000, rate, dist, 7)
    u127, _ = utilisation(12_000, rate, dist, 127)
    print(f"{name:<31} a = {a:7.2f}  stop-and-wait {u1:6.1%}  "
          f"W=7 {u7:6.1%}  W=127 {u127:6.1%}")

# ---- extensions ----
print("\n--- extensions ---")
u, a = utilisation(12_000, 10e6, 36_000_000, 1)
w_sat = math.ceil(1 + 2 * a)
print(f"Satellite: a = {a:.0f}, smallest window for 100% = 1 + 2a = {1+2*a:.0f} -> {w_sat} frames")
u, a = utilisation(12_000, 1e9, 400_000, 1)
w = math.ceil(1 + 2 * a)
print(f"Head office 400 km, 1 Gbps: tx = 12 us, prop = 2 ms, a = {a:.2f}")
print(f"  stop-and-wait U = {u:.3%} = {u*1000:.2f} Mbps; smallest window = {1+2*a:.2f} -> {w} frames")
n_gbn = math.ceil(math.log2(w + 1)); n_sr = math.ceil(math.log2(2 * w))
print(f"  sequence bits: Go-Back-N {n_gbn} (W <= 2^n - 1), Selective Repeat {n_sr} (W <= 2^(n-1))")
u64, _ = utilisation(12_000, 1e9, 400_000, 64)
print(f"  Selective Repeat W=64: U = {u64:.2%}, throughput = {u64*1000:.1f} Mbps, "
      f"receiver buffer = {64*1500:,} bytes; full window buffer = {w*1500:,} bytes")
