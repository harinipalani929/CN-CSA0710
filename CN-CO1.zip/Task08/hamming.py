"""Hamming(7,4) code: correct a single-bit error in a 4-bit sensor reading."""


def encode(d):                     # d = [d1, d2, d3, d4]
    p1 = d[0] ^ d[1] ^ d[3]
    p2 = d[0] ^ d[2] ^ d[3]
    p3 = d[1] ^ d[2] ^ d[3]
    return [p1, p2, d[0], p3, d[1], d[2], d[3]]      # positions 1..7


def decode(c):
    # TODO 1 (completed): syndrome, correct bit pos, return pos and data bits 3,5,6,7
    c = c[:]
    s1 = c[0] ^ c[2] ^ c[4] ^ c[6]          # positions 1,3,5,7
    s2 = c[1] ^ c[2] ^ c[5] ^ c[6]          # positions 2,3,6,7
    s3 = c[3] ^ c[4] ^ c[5] ^ c[6]          # positions 4,5,6,7
    pos = s1 + 2 * s2 + 4 * s3
    if pos != 0:
        c[pos - 1] ^= 1
    return pos, [c[2], c[4], c[5], c[6]]


word = encode([1, 0, 1, 1])
print("codeword       :", "".join(map(str, word)))
for flip in (None, 5):
    rx = word[:]
    if flip:
        rx[flip - 1] ^= 1
    pos, data = decode(rx)
    print(f"error at {str(flip):<4}: syndrome {pos}, data {''.join(map(str, data))}")

# ---- extensions ----
print("\n--- double error demo (flip positions 2 and 5) ---")
rx = word[:]
rx[1] ^= 1; rx[4] ^= 1
pos, data = decode(rx)
print(f"syndrome {pos} (= 2 xor 5 = 7) -> decoder flips bit {pos}, data {''.join(map(str, data))} (sent 1011) WRONG")

print("\n--- worked example 0110011 received as 0110111 ---")
rx = [int(b) for b in "0110111"]
pos, data = decode(rx)
print(f"syndrome {pos}, data {''.join(map(str, data))}")

print("\n--- FEC vs ARQ at BER = 1e-3 ---")
ber, t_retx = 1e-3, 40.0
p16 = 1 - (1 - ber) ** 16
exp_tx = 1 / (1 - p16)
print(f"ARQ: P(16-bit reading corrupted) = {p16:.4%}; mean transmissions {exp_tx:.4f}; "
      f"mean bits {16*exp_tx:.2f}; mean extra delay {t_retx*(exp_tx-1):.3f} ms; worst case >= {t_retx:.0f} ms")
p_fail = 1 - (1 - ber) ** 21 - 21 * ber * (1 - ber) ** 20
print(f"FEC: 21 bits per reading (5 check bits, {5/16:.2%} overhead); "
      f"P(2+ errors, uncorrectable) = {p_fail:.2e}; extra delay 0 ms")
