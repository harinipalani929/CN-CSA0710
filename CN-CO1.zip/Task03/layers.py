"""How data is wrapped by each layer at the sender and unwrapped at the receiver."""

LAYERS = [("Application", "HTTP"), ("Transport", "TCP"), ("Network", "IP"),
          ("Data link", "ETH")]


def send(message):
    pdu = message
    for layer, tag in LAYERS:
        # TODO 1 (completed): wrap with header "[tag|"; trailer "|FCS]" for ETH, "]" otherwise
        trailer = "|FCS]" if tag == "ETH" else "]"
        pdu = "[" + tag + "|" + pdu + trailer
        print(f"{layer:<12} adds {tag:<4} -> {len(pdu):>3} bytes")
    return pdu


def receive(frame):
    pdu = frame
    for layer, tag in reversed(LAYERS):
        head = "[" + tag + "|"
        tail = "|FCS]" if tag == "ETH" else "]"
        assert pdu.startswith(head) and pdu.endswith(tail), f"{layer}: bad header"
        pdu = pdu[len(head):-len(tail)]
    return pdu


frame = send("GET /results")
print("on the wire:", frame)
print("delivered  :", receive(frame))
print(f"overhead   : {len(frame) - len('GET /results')} bytes for 12 bytes of data")

# ---- extension: 1,400-byte message ----
print("\n--- 1,400-byte message ---")
big = "x" * 1400
LAYERS_QUIET = LAYERS
pdu = big
for layer, tag in LAYERS:
    pdu = "[" + tag + "|" + pdu + ("|FCS]" if tag == "ETH" else "]")
ovh = len(pdu) - 1400
print(f"frame {len(pdu)} bytes, overhead {ovh} bytes = {ovh/len(pdu):.1%} of the frame "
      f"({ovh/1400:.1%} of the data)")
small = len(frame) - 12
print(f"12-byte message: overhead {small} bytes = {small/len(frame):.1%} of the frame "
      f"({small/12:.1%} of the data)")
