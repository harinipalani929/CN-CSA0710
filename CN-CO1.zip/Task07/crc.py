"""CRC error detection for frames sent between two switches."""


def mod2_div(dividend, divisor):
    """Return the remainder of modulo-2 (XOR) division of two bit strings."""
    rem = list(dividend)
    for i in range(len(dividend) - len(divisor) + 1):
        # TODO 1 (completed): if the leading bit is 1, XOR the divisor in at position i
        if rem[i] == "1":
            for j in range(len(divisor)):
                rem[i + j] = "0" if rem[i + j] == divisor[j] else "1"
    return "".join(rem[-(len(divisor) - 1):])


def encode(data, gen):
    crc = mod2_div(data + "0" * (len(gen) - 1), gen)
    return data + crc


def check(frame, gen):
    return set(mod2_div(frame, gen)) == {"0"}


GEN = "1011"                                   # x^3 + x + 1
frame = encode("1101011011", GEN)
print("transmitted:", frame)
print("no error   :", check(frame, GEN))
bad = frame[:4] + ("1" if frame[4] == "0" else "0") + frame[5:]
print("1-bit error:", check(bad, GEN))
burst = frame[:2] + "".join("1" if b == "0" else "0" for b in frame[2:5]) + frame[5:]
print("3-bit burst:", check(burst, GEN))

# ---- extensions ----
def xor_at(frame, pattern, pos):
    f = list(frame)
    for k, p in enumerate(pattern):
        if p == "1":
            f[pos + k] = "0" if f[pos + k] == "1" else "1"
    return "".join(f)

print("\n--- extensions ---")
print("received 1101011011101 accepted?", check("1101011011101", GEN),
      " remainder =", mod2_div("1101011011101", GEN))
print("undetected patterns (generator XOR-ed into the frame, i.e. error = multiple of G):")
for name, pat in [("1011 (3 bits)", "1011"), ("11101 = (x+1)G (4 bits)", "11101")]:
    print(f"  {name:<26} accepted? {check(xor_at(frame, pat, 0), GEN)}")
two_apart = "10000001"                       # two flipped bits, 7 positions apart
print(f"  two bits 7 apart (10000001) accepted? {check(xor_at(frame, two_apart, 0), GEN)}")
print("method comparison on the same frame (even parity of the 13 bits):")
def parity_ok(f): return f.count("1") % 2 == 0
for name, pat in [("2-bit 11", "11"), ("4-bit 1111", "1111"), ("3-bit 1011", "1011"),
                  ("2-bit 7 apart", "10000001"), ("4-bit 11101", "11101")]:
    e = xor_at(frame, pat, 0)
    p_ok = parity_ok(e) == parity_ok(frame)
    print(f"  {name:<14} CRC detects: {not check(e, GEN)!s:<5}  parity detects: {not p_ok}")
